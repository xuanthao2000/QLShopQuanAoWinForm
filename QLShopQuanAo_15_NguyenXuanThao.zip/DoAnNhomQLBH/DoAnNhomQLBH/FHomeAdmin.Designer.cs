﻿namespace DoAnNhomQLBH
{
    partial class FHomeAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btDangXuat = new System.Windows.Forms.Button();
            this.btQLDH = new System.Windows.Forms.Button();
            this.btQLKH = new System.Windows.Forms.Button();
            this.btQLNV = new System.Windows.Forms.Button();
            this.btQLSP = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.panel1.Controls.Add(this.btDangXuat);
            this.panel1.Controls.Add(this.btQLDH);
            this.panel1.Controls.Add(this.btQLKH);
            this.panel1.Controls.Add(this.btQLNV);
            this.panel1.Controls.Add(this.btQLSP);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(870, 67);
            this.panel1.TabIndex = 2;
            // 
            // btDangXuat
            // 
            this.btDangXuat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btDangXuat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDangXuat.ForeColor = System.Drawing.Color.White;
            this.btDangXuat.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btDangXuat.Location = new System.Drawing.Point(711, 11);
            this.btDangXuat.Margin = new System.Windows.Forms.Padding(2);
            this.btDangXuat.Name = "btDangXuat";
            this.btDangXuat.Size = new System.Drawing.Size(133, 45);
            this.btDangXuat.TabIndex = 5;
            this.btDangXuat.Text = "Đăng xuất";
            this.btDangXuat.UseVisualStyleBackColor = false;
            this.btDangXuat.Click += new System.EventHandler(this.btDangXuat_Click);
            // 
            // btQLDH
            // 
            this.btQLDH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btQLDH.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btQLDH.ForeColor = System.Drawing.Color.White;
            this.btQLDH.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btQLDH.Location = new System.Drawing.Point(541, 10);
            this.btQLDH.Margin = new System.Windows.Forms.Padding(2);
            this.btQLDH.Name = "btQLDH";
            this.btQLDH.Size = new System.Drawing.Size(141, 45);
            this.btQLDH.TabIndex = 4;
            this.btQLDH.Text = "Quản Lý Đơn Hàng";
            this.btQLDH.UseVisualStyleBackColor = false;
            this.btQLDH.Click += new System.EventHandler(this.btQLDH_Click);
            // 
            // btQLKH
            // 
            this.btQLKH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btQLKH.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btQLKH.ForeColor = System.Drawing.Color.White;
            this.btQLKH.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btQLKH.Location = new System.Drawing.Point(195, 11);
            this.btQLKH.Margin = new System.Windows.Forms.Padding(2);
            this.btQLKH.Name = "btQLKH";
            this.btQLKH.Size = new System.Drawing.Size(146, 45);
            this.btQLKH.TabIndex = 3;
            this.btQLKH.Text = "Quản Lý Khách Hàng";
            this.btQLKH.UseVisualStyleBackColor = false;
            this.btQLKH.Click += new System.EventHandler(this.btQLKH_Click);
            // 
            // btQLNV
            // 
            this.btQLNV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btQLNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btQLNV.ForeColor = System.Drawing.Color.White;
            this.btQLNV.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btQLNV.Location = new System.Drawing.Point(25, 11);
            this.btQLNV.Margin = new System.Windows.Forms.Padding(2);
            this.btQLNV.Name = "btQLNV";
            this.btQLNV.Size = new System.Drawing.Size(141, 45);
            this.btQLNV.TabIndex = 2;
            this.btQLNV.Text = "Quản Lý Nhân Viên";
            this.btQLNV.UseVisualStyleBackColor = false;
            this.btQLNV.Click += new System.EventHandler(this.btQLNV_Click);
            // 
            // btQLSP
            // 
            this.btQLSP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btQLSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btQLSP.ForeColor = System.Drawing.Color.White;
            this.btQLSP.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btQLSP.Location = new System.Drawing.Point(370, 11);
            this.btQLSP.Margin = new System.Windows.Forms.Padding(2);
            this.btQLSP.Name = "btQLSP";
            this.btQLSP.Size = new System.Drawing.Size(141, 45);
            this.btQLSP.TabIndex = 1;
            this.btQLSP.Text = "Quản Lý Sản Phẩm";
            this.btQLSP.UseVisualStyleBackColor = false;
            this.btQLSP.Click += new System.EventHandler(this.btQLSP_Click);
            // 
            // FHomeAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(870, 645);
            this.Controls.Add(this.panel1);
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FHomeAdmin";
            this.Text = "FHomeAdmin";
            this.Load += new System.EventHandler(this.FHomeAdmin_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btQLSP;
        private System.Windows.Forms.Button btDangXuat;
        private System.Windows.Forms.Button btQLDH;
        private System.Windows.Forms.Button btQLKH;
        private System.Windows.Forms.Button btQLNV;
    }
}